﻿using System;
using System.Linq;

namespace P01.Sorting
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            BubbleSort.Sort(arr);

            Console.WriteLine(string.Join(" ", arr));
            Console.ReadLine();
        }
    }
}
