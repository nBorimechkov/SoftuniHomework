﻿public enum CoffeeType
{
    None,
    Espresso,
    Latte,
    Irish
}

