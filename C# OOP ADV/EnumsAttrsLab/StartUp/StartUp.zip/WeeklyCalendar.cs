﻿using System.Collections.Generic;

public class WeeklyCalendar
{
    void AddEntry(string weekday, string notes) { }
    public List<WeeklyEntry> WeeklySchedule { get; }

}
