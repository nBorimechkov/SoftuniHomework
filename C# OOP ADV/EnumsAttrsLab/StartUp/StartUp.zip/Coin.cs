﻿public enum Coin
{
    None,
    One,
    Two,
    Five = 5,
    Ten = 10,
    Twenty = 20,
    Fifty = 50
}

