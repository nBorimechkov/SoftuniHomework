﻿public interface IBrowse
{
    void Browse(string[] websites);
}

