﻿public interface IBiologicalEntity
{
    string Name { get; }
    string Birthdate { get; }
}

