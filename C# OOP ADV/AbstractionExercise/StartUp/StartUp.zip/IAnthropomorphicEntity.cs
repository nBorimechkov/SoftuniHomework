﻿public interface IAnthropomorphicEntity
{
    string Id { get; }
}

