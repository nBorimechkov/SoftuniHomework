﻿using System;
using System.Collections.Generic;
using System.Linq;
public class Program
{
    static void Main(string[] args)
    {
        foreach (CardSuits suit in Enum.GetValues(typeof(CardSuits)))
        {
            foreach (CardRanks rank in Enum.GetValues(typeof(CardRanks)))
            {
                Console.WriteLine(rank + " of " + suit);
            }
        }
        Console.ReadLine();
    }
}

