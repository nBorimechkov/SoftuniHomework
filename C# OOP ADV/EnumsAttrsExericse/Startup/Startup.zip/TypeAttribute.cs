﻿using System;
[AttributeUsage(AttributeTargets.Class)]
public class TypeAttribute : Attribute
{
}

